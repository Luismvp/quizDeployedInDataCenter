sudo ./configBBDD.sh
sudo ./configGluster.sh
sudo ./configQuiz2.sh
sudo ./configLB.sh
sudo ./configFW.sh
